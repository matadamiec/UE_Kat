from models.movie import Movie
import csv

source_file = open("data_source/movies.csv")
csv_file = csv.DictReader(source_file)


# with source_file as file:
#     csv_file = csv.DictReader(file)
#     for row in csv_file:
#         print(dict(row))

def print(self):
    for row in self.csv_file:
        print(dict(row))


def get(self):
    return print()
